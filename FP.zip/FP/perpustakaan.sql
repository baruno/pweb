-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2018 at 04:48 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_anggota`
--

DROP TABLE IF EXISTS `tb_anggota`;
CREATE TABLE `tb_anggota` (
  `nim` int(20) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `tempat_lahir` varchar(80) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `prodi` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_anggota`
--

INSERT INTO `tb_anggota` (`nim`, `nama`, `tempat_lahir`, `tgl_lahir`, `jk`, `prodi`) VALUES
(5113244, 'mochammad', 'trenggalek', '2018-05-05', 'L', 'informatika'),
(5114184, 'Baruno', 'Kediri', '1995-04-19', 'L', 'informatika'),
(5114200, 'adit', 'Malang', '1998-02-03', 'L', 'informatika');

-- --------------------------------------------------------

--
-- Table structure for table `tb_buku`
--

DROP TABLE IF EXISTS `tb_buku`;
CREATE TABLE `tb_buku` (
  `id` int(9) NOT NULL,
  `judul` varchar(200) DEFAULT NULL,
  `pengarang` varchar(100) DEFAULT NULL,
  `penerbit` varchar(150) DEFAULT NULL,
  `tahun_terbit` varchar(4) DEFAULT NULL,
  `isbn` varchar(25) DEFAULT NULL,
  `jumlah_buku` int(3) DEFAULT NULL,
  `lokasi` enum('rak 1','rak 2','rak 3') DEFAULT NULL,
  `tgl_input` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_buku`
--

INSERT INTO `tb_buku` (`id`, `judul`, `pengarang`, `penerbit`, `tahun_terbit`, `isbn`, `jumlah_buku`, `lokasi`, `tgl_input`) VALUES
(2, 'belajar coding gampang', 'son', 'elek', '2008', '45', 1, 'rak 1', '2018-05-05'),
(3, 'photoshop', 'parman', 'elekmedia', '2004', '123bnm', 2, 'rak 3', '2018-05-10'),
(4, 'belajar php mudah', 'nonot', 'elekmedia', '2006', '125', 0, 'rak 2', '2018-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

DROP TABLE IF EXISTS `tb_transaksi`;
CREATE TABLE `tb_transaksi` (
  `id` int(9) NOT NULL,
  `judul` varchar(200) DEFAULT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `nama` varchar(250) DEFAULT NULL,
  `tgl_pinjam` varchar(30) DEFAULT NULL,
  `tgl_kembali` varchar(30) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id`, `judul`, `nim`, `nama`, `tgl_pinjam`, `tgl_kembali`, `status`) VALUES
(1, 'belajar php', '5114184', 'Baruno', '01-01-2018', '05-01-2018', 'pinjam'),
(2, 'belajar coding gampang', '5114184', 'Baruno', '01-05-2018', '23-05-2018', 'kembali'),
(6, 'photoshop', '5113244', 'mochammad', '28-05-2018', '04-06-2018', 'kembali'),
(7, 'photoshop', '5113244', 'mochammad', '28-05-2018', '04-06-2018', 'kembali'),
(8, 'belajar coding gampang', '5114200', 'adit', '28-05-2018', '04-06-2018', 'kembali'),
(9, 'belajar coding gampang', '5113244', 'mochammad', '28-05-2018', '1528668000', 'kembali'),
(10, 'belajar coding gampang', '5113244', 'mochammad', '28-05-2018', '1528668000', 'kembali'),
(11, 'belajar coding gampang', '5113244', 'mochammad', '28-05-2018', '11-06-18', 'pinjam');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `level` varchar(30) DEFAULT NULL,
  `foto` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`, `nama`, `level`, `foto`) VALUES
(2, 'admin', 'admin', 'nonot', 'admin', 'foto.jpg'),
(3, 'son', 'son', 'son', 'user', 'foto.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_anggota`
--
ALTER TABLE `tb_anggota`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `tb_buku`
--
ALTER TABLE `tb_buku`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_buku`
--
ALTER TABLE `tb_buku`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
